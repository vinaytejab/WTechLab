from audioop import add
from typing import List
import fastapi as _fastapi
import uvicorn
from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel

app = _fastapi.FastAPI()


# app = FastAPI()

origins = [
    "http://localhost",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
class Data(BaseModel):
    num1: int
    num2: int

@app.get("/",tags=["root"])
async def root():
    return {"message": "Test TOTP - Hi Vinay from backend tesing to frontend ISC"}

@app.post("/sum")
async def sum(nums: Data):
# async def sum(num1: int,num2: int):
    # print(num1,num2)
    adding=nums.num1+nums.num2
    # adding=num1+num2
    return {"Status":adding}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=5000)
    # 127.0.0.1 
