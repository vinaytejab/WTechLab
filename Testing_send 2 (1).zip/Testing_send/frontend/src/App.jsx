import React, { useState } from "react";

// import Button from "react-bootstrap/Button";

const App =() => {
  const [num1, setnum1] = useState("");
  const [num2, setnum2] = useState("");
  // const [errorMessage, setErrorMessage] = useState("");
  const [sum,setSum] = useState("");

  const submitAdd =async() => {
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({num1 : num1,num2 : num2}),
    };
    console.log(requestOptions);
    const response = await fetch("http://localhost:5000/sum",requestOptions);
    const data =await response.json();

    if (!response.ok) {
      // setErrorMessage(data.detail);
      console.log(data.detail);
      console.log("something worng");
    } else {
      // setToken(data.access_token);
      console.log(data.detail);
      console.log("111111")
      setSum(data.Status);
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    submitAdd();
  };

  return (
    <div>
      <h3><b>Hello Vinay,--- TOTP from frontend</b></h3>
      {/* <h1><b>{message}</b></h1> */}
      <br></br>

      <form align = "center" onSubmit={handleSubmit}>
        <input 
          type="num1" 
          placeholder="Number1" 
          className='num'  
          onChange={(e) => setnum1(e.target.value)}
          required
        />
          <br></br><br></br>
        <input 
          type="num2" 
          placeholder="Number2" 
          className='num'  
          onChange={(e) => setnum2(e.target.value)}
          required
        />
        <br></br><br></br>
        <p>{sum}</p>
        <button className="button is-primary" type="submit"><b>SUM</b></button>
      </form>
    </div>
  );
};

export default App;
